# 🚀 Bienvenido a tu Gestor de Finanzas Personales (FinPer)

Esta es una suite completa de finanzas personales diseñada para darte control total sobre tus ingresos, gastos diarios, tarjetas de crédito, deudas y proyecciones presupuestarias.

---

## ⚡ Inicio Rápido en 3 Pasos

### 1. Requisitos
Tener instalado **Node.js** (versión 18 o superior). Puedes descargarlo gratis desde [nodejs.org](https://nodejs.org).

### 2. Instalar dependencias
Abre una terminal (PowerShell, CMD o Terminal de VS Code) dentro de esta carpeta y ejecuta:
```bash
npm install
```

### 3. Ejecutar la aplicación
```bash
npm run dev
```
Abre tu navegador en:
👉 **http://localhost:5173**

---

## 💾 ¿Dónde se guardan mis datos?

¡**La aplicación funciona 100% en local sin necesidad de internet ni bases de datos complejas**!
- Todos tus registros, categorías y configuraciones se guardan de forma segura y privada directamente en el almacenamiento local de tu navegador (`localStorage`).
- Puedes ir a la pestaña **Respaldos** (ícono de disco en la barra superior) en cualquier momento para:
  - 📥 **Exportar a Excel (.xlsx)** o **JSON** con un solo clic.
  - 📤 **Restaurar respaldos** cuando lo desees.

---

## ☁️ (Opcional) Sincronización en la Nube con Supabase

Si en el futuro deseas que tus datos se sincronicen en tiempo real entre tu PC y tu teléfono móvil:
1. Crea una cuenta gratuita en [supabase.com](https://supabase.com).
2. Crea un nuevo proyecto.
3. Ve a la sección **SQL Editor**, copia y ejecuta el contenido del archivo `supabase_schema.sql` incluido en esta carpeta.
4. Duplica el archivo `.env.example` con el nombre `.env.local` y coloca tus credenciales:
   ```env
   VITE_SUPABASE_URL=https://tu-proyecto.supabase.co
   VITE_SUPABASE_ANON_KEY=tu_clave_anonima_supabase
   ```
5. Reinicia la aplicación con `npm run dev`.

---

## 📱 Características Principales

1. **Dashboard General**: Métricas de ingresos, egresos, balance neto, tasa de ahorro y gráficos de distribución.
2. **Registro Rápido**: Formulario optimizado para registrar gastos o ingresos en segundos con categorización automática.
3. **Control de Tarjetas de Crédito**: Manejo de fechas de corte y límites de pago, estados de cuenta y simulación de ciclos.
4. **Mis Deudas**: Gestor de amortización, cálculo de cuotas e intereses, cronograma y pagos parciales.
5. **Proyecciones Financieras**: Planificación mes a mes con ingresos recurrentes, gastos fijos y eventos únicos.
6. **Buscador Rápido**: Presiona `Ctrl + K` en cualquier momento para buscar cualquier transacción por concepto, entidad o categoría.
7. **Modo Oscuro / Claro**: Cambia de tema con el botón del sol/luna en la barra de navegación.

¡Que disfrutes gestionando tus finanzas!
