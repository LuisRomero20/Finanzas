import { createClient } from '@supabase/supabase-js';

const rawUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
const rawKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

export const isSupabaseConfigured = Boolean(
  rawUrl &&
  rawKey &&
  !rawUrl.includes('tu_url_aqui') &&
  !rawUrl.includes('tu-proyecto') &&
  rawUrl.startsWith('http')
);

// Si hay credenciales válidas en .env.local se conecta a Supabase;
// de lo contrario funciona en modo 100% local (persistiendo en localStorage sin errores).
export const supabase = isSupabaseConfigured
  ? createClient(rawUrl, rawKey)
  : (new Proxy({}, {
      get: (_target, prop) => {
        if (prop === 'auth') {
          return {
            getSession: async () => ({ data: { session: null }, error: null }),
            onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
            signInWithPassword: async () => ({ data: null, error: new Error('Modo Local (Supabase no configurado)') }),
            signOut: async () => ({ error: null }),
            signUp: async () => ({ data: null, error: new Error('Modo Local (Supabase no configurado)') }),
          };
        }
        if (prop === 'from') {
          return () => {
            const chain: any = {
              select: () => chain,
              insert: () => chain,
              upsert: () => chain,
              delete: () => chain,
              update: () => chain,
              eq: () => chain,
              like: () => chain,
              not: () => chain,
              order: () => chain,
              in: () => chain,
              single: async () => ({ data: null, error: null }),
              then: (resolve: any) => Promise.resolve({ data: [], error: null, count: 0 }).then(resolve),
            };
            return chain;
          };
        }
        return () => Promise.resolve({ data: null, error: null });
      }
    }) as any);

// Tipos para Supabase
export interface SupabaseUsuario {
  id: string;
  nombre: string;
  email: string;
  created_at: string;
}

export interface SupabaseDeuda {
  id: string;
  usuario_id: string;
  acreedor: string;
  monto: number;
  tasa_anual: number;
  plazo_meses: number;
  meses_pagados: number;
  fecha_inicio: string;
  tipo_tasa: 'nominal' | 'efectiva';
  moneda: string;
  estado: 'activa' | 'pagada' | 'proximo_vencer';
  created_at: string;
  updated_at: string;
}
