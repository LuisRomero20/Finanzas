export interface Transaction {
  id: string;
  Tipo: 'Ingreso' | 'Egreso';
  Fecha: string;
  Categoria: string;
  Concepto: string;
  Monto: number;
  Entidad: string;
  Mes: string;
  estado?: 'confirmado' | 'pendiente' | 'provisional';
}

export { CONCEPTO_A_CATEGORIA, CATEGORIAS_PERSONALES } from './categoryClassification';

export const CATEGORIAS = [
  'Deuda',
  'Gasto',
  'Otro Egre',
  'Otro Ing',
  'Servicio',
  'Sueldo',
  'Tarjeta',
] as const;

export type CategoriaType = typeof CATEGORIAS[number];

export const MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'
] as const;

export const ENTIDADES = [
  'BCP', 'Interbank', 'BBVA', 'Efectivo'
] as const;

export const LINE_OVERRIDES: Record<string, number> = {};

export const ACCOUNT_LABELS: Record<string, string> = {
  'BCP': 'Cuenta Principal',
  'Interbank': 'Cuenta Ahorro',
  'BBVA': 'Tarjeta Crédito',
  'Efectivo': 'Efectivo',
};

export const masterTransactions: Transaction[] = [];
