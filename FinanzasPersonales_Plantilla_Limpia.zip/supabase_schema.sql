-- ====================================================================
-- ESQUEMA DE BASE DE DATOS SUPABASE PARA FINPER (OPCIONAL)
-- ====================================================================
-- Si deseas activar la sincronización en la nube:
-- 1. Crea un proyecto gratuito en https://supabase.com
-- 2. Ve al 'SQL Editor' en tu panel de Supabase.
-- 3. Pega y ejecuta el siguiente script SQL.
-- 4. Copia tu URL y anon key en el archivo .env.local

CREATE TABLE IF NOT EXISTS public.transacciones (
  id text PRIMARY KEY,
  tipo text,
  fecha text,
  concepto text,
  categoria text,
  entidad text,
  monto numeric,
  mes text,
  estado text DEFAULT 'confirmado',
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Habilitar Row Level Security (RLS) opcional o acceso anónimo según tus políticas
ALTER TABLE public.transacciones ENABLE ROW LEVEL SECURITY;

-- Política de lectura y escritura libre para anon (personal)
CREATE POLICY "Permitir todo a usuarios anon" ON public.transacciones
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);
